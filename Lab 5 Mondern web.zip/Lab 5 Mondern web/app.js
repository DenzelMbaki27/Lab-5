const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const path = require('path');

// Import routes
const clientRoutes = require('./routes/clientRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Use express-ejs-layouts middleware
app.use(expressLayouts);
app.set('layout', 'layouts/main');

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/', clientRoutes);

// Start server
app.listen(PORT, () => {
  console.log(`NorthStar Advisory Services Portal running on http://localhost:${PORT}`);
});

module.exports = app;