const express = require('express');
const router = express.Router();
const clientController = require('../controllers/clientController');


router.get('/', (req, res) => {
  res.render('pages/home', {
    title: 'NorthStar Advisory Services - Home',
    currentPage: 'home'
  });
});


router.get('/clients', (req, res) => {
  const clients = clientController.getAllClients();
  res.render('pages/clients', {
    title: 'Client Portfolio - NorthStar Advisory Services',
    currentPage: 'clients',
    clients: clients,
    formatCurrency: clientController.formatCurrency,
    getRiskCategoryColor: clientController.getRiskCategoryColor
  });
});


router.get('/clients/:id', (req, res) => {
  const client = clientController.getClientById(req.params.id);

  if (!client) {
    return res.status(404).render('pages/error', {
      title: 'Client Not Found - NorthStar Advisory Services',
      currentPage: 'clients',
      error: 'Client not found'
    });
  }

  res.render('pages/clientDetails', {
    title: `${client.name} - NorthStar Advisory Services`,
    currentPage: 'clients',
    client: client,
    formatCurrency: clientController.formatCurrency,
    formatDate: clientController.formatDate,
    getRiskCategoryColor: clientController.getRiskCategoryColor
  });
});

module.exports = router;