# NorthStar Advisory Services - Client Information Portal

A dynamic web application built with Node.js, Express.js, and EJS templates for NorthStar Advisory Services. This application demonstrates server-side template rendering with reusable layouts and dynamic data presentation.

## Project Overview

This application serves as an internal client information portal for NorthStar Advisory Services, providing advisors and compliance teams with a centralized interface to view client records. The system dynamically generates pages using reusable template structures and operational datasets, ensuring consistent user experience and real-time data visibility.

### Key Features

- **Dynamic Page Generation**: Server-rendered pages using EJS templates
- **Reusable Layout Architecture**: Shared header, navigation, and footer components
- **Client Portfolio Management**: View all clients and detailed client profiles
- **Risk Category Visualization**: Color-coded risk indicators (Low/Medium/High)
- **Responsive Design**: Bootstrap-based interface that works on all devices
- **Search Functionality**: Real-time client search in the portfolio view

## Installation Instructions

### Prerequisites

- Node.js (version 14 or higher)
- npm (comes with Node.js)

### Setup Steps

1. **Clone or download the project files**

2. **Navigate to the project directory**
   ```bash
   cd "Lab 5 Mondern web"
   ```

3. **Install dependencies**
   ```bash
   npm install
   ```

4. **Start the application**
   ```bash
   npm start
   ```

5. **Open your browser and navigate to**
   ```
   http://localhost:3000
   ```

## Application Startup Instructions

The application will start on port 3000 by default. You can change the port by setting the `PORT` environment variable.

### Development Mode

For development with automatic restarts:
```bash
npm run dev
```

## Implemented Routes

| Route | Method | Description |
|-------|--------|-------------|
| `/` | GET | Home dashboard with summary statistics |
| `/clients` | GET | Client portfolio list view |
| `/clients/:id` | GET | Individual client detail view |

## Project Structure

```
project-root/
│
├── app.js                          # Main application file
├── package.json                    # Dependencies and scripts
│
├── routes/
│   └── clientRoutes.js            # Client-related routes
│
├── controllers/
│   └── clientController.js        # Business logic for clients
│
├── data/
│   └── clients.json               # Client data storage
│
├── views/
│   ├── layouts/
│   │   └── main.ejs              # Main layout template
│   ├── partials/
│   │   ├── header.ejs            # Header partial
│   │   ├── navigation.ejs        # Navigation partial
│   │   └── footer.ejs            # Footer partial
│   └── pages/
│       ├── home.ejs               # Home page
│       ├── clients.ejs            # Clients list page
│       └── clientDetails.ejs      # Client details page
│
└── public/
    ├── css/
    │   └── style.css             # Custom styles
    └── images/                   # Static images
```

## Technologies Used

- **Node.js**: Runtime environment
- **Express.js**: Web framework
- **EJS**: Template engine
- **Express EJS Layouts**: Layout middleware
- **Bootstrap 5**: CSS framework
- **Font Awesome**: Icons
- **JSON**: Data storage format

## Data Structure

The application uses a JSON file (`data/clients.json`) containing client information with the following structure:

```json
{
  "id": 1,
  "name": "John Smith",
  "email": "john.smith@email.com",
  "phone": "(555) 123-4567",
  "riskCategory": "Low",
  "investmentAmount": 250000,
  "advisor": "Sarah Johnson",
  "lastReview": "2024-01-15",
  "accountType": "Individual",
  "portfolioValue": 275000,
  "annualIncome": 95000,
  "netWorth": 450000,
  "objectives": "Retirement planning, Wealth preservation",
  "notes": "Conservative investor focused on long-term growth"
}
```

## Features Demonstrated

1. **Server-Side Rendering**: All pages are rendered on the server using EJS templates
2. **Layout Inheritance**: All pages use the same layout structure
3. **Partial Templates**: Reusable header, navigation, and footer components
4. **Dynamic Data Binding**: Client data is dynamically inserted into templates
5. **Helper Functions**: Currency formatting, date formatting, and risk category styling
6. **Responsive Design**: Works on desktop, tablet, and mobile devices
7. **Search Functionality**: Real-time filtering of client list
8. **Consistent Styling**: Unified visual design across all pages

## Security Considerations

- Client data is stored in a local JSON file (in production, this would be replaced with a secure database)
- No authentication implemented (would be required for production use)
- Input validation and sanitization would be needed for production deployment

## Future Enhancements

- Database integration (MongoDB, PostgreSQL, etc.)
- User authentication and authorization
- CRUD operations for client management
- Advanced search and filtering
- Data export functionality
- Audit logging
- API endpoints for mobile app integration