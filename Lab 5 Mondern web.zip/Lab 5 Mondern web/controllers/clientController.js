const fs = require('fs');
const path = require('path');

class ClientController {
  constructor() {
    this.clientsDataPath = path.join(__dirname, '../data/clients.json');
  }

  
  loadClients() {
    try {
      const data = fs.readFileSync(this.clientsDataPath, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      console.error('Error loading clients data:', error);
      return [];
    }
  }

  
  getAllClients() {
    return this.loadClients();
  }

 
  getClientById(id) {
    const clients = this.loadClients();
    return clients.find(client => client.id === parseInt(id));
  }

 
  getRiskCategoryColor(riskCategory) {
    switch (riskCategory.toLowerCase()) {
      case 'low':
        return 'success';
      case 'medium':
        return 'warning';
      case 'high':
        return 'danger';
      default:
        return 'secondary';
    }
  }

  
  formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  }

  
  formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }
}

module.exports = new ClientController();